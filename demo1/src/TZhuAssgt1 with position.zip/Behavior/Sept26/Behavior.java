package Behavior.Sept26;

public interface Behavior {

	public void behave();
}
