package CalcFix.Sept26;

public interface CalcFixer {

	public void fix();
	public double getAnswer();
}
