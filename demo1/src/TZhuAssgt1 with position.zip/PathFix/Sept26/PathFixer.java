package PathFix.Sept26;

import assgt1.v1.*;
import java.util.*;

public interface PathFixer{
	
	public void fixRight();
	public void fixLeft();

}
